import Foundation

protocol QuestCatalogRepository {
    var catalogVersion: String { get }
    var quests: [QuestDefinition] { get }
    func quest(id: Int) -> QuestDefinition?
}

enum QuestCatalogError: Error {
    case resourceMissing
    case invalidCatalog
}

final class BundledQuestCatalog: QuestCatalogRepository {
    let catalogVersion: String
    let quests: [QuestDefinition]
    private let byID: [Int: QuestDefinition]

    init(bundle: Bundle = .main) throws {
        guard let url = bundle.url(forResource: "quests_v1", withExtension: "json") else {
            throw QuestCatalogError.resourceMissing
        }
        let data = try Data(contentsOf: url)
        let envelope = try JSONDecoder().decode(QuestCatalogEnvelope.self, from: data)

        guard envelope.questCount == envelope.quests.count,
              Set(envelope.quests.map(\.id)).count == envelope.quests.count else {
            throw QuestCatalogError.invalidCatalog
        }

        catalogVersion = envelope.catalogVersion
        quests = envelope.quests
        byID = Dictionary(uniqueKeysWithValues: quests.map { ($0.id, $0) })
    }

    func quest(id: Int) -> QuestDefinition? {
        byID[id]
    }
}
