import Foundation

struct RecommendationContext {
    var selectedMood: String?
    var allowedMovement: Set<String> = ["Stay Here", "Few Steps"]
    var activeContexts: Set<String> = ["Anywhere"]
    var recentSeedIDs: [Int] = []
    var recentWorlds: [String] = []
    var recentCanonicalLenses: [String] = []
    var recentFindHeavy: [Bool] = []
}

protocol QuestRecommending {
    func recommend(from quests: [QuestDefinition], context: RecommendationContext) -> QuestDefinition?
}

struct RecommendationEngineV1: QuestRecommending {
    func recommend(from quests: [QuestDefinition], context: RecommendationContext) -> QuestDefinition? {
        let eligible = quests.filter { quest in
            guard quest.rank != "Experimental",
                  quest.defaultSurface != "Experimental only",
                  context.allowedMovement.contains(quest.movement),
                  !context.recentSeedIDs.contains(quest.id)
            else { return false }

            if let mood = context.selectedMood, !quest.moods.contains(mood) {
                return false
            }

            if context.recentCanonicalLenses.suffix(3).contains(quest.canonicalLens) {
                return false
            }

            if context.recentWorlds.suffix(2).allSatisfy({ $0 == quest.world }) {
                return false
            }

            if context.recentFindHeavy.suffix(2).allSatisfy({ $0 }) && quest.isFindHeavy {
                return false
            }

            if quest.defaultSurface == "Contextual default" {
                let questSpecific = Set(quest.context).subtracting(["Anywhere", "Public Space"])
                if !questSpecific.isEmpty && questSpecific.isDisjoint(with: context.activeContexts) {
                    return false
                }
            }

            return true
        }

        return eligible
            .map { ($0, score($0, context: context)) }
            .max(by: { $0.1 < $1.1 })?
            .0
    }

    private func score(_ quest: QuestDefinition, context: RecommendationContext) -> Double {
        var score = 0.0

        switch quest.rank {
        case "Featured": score += 0.15
        case "Recommended": score += 0.11
        case "Niche": score += 0.05
        default: score += 0.02
        }

        if let mood = context.selectedMood, quest.moods.contains(mood) {
            score += 0.30
        } else if context.selectedMood == nil {
            score += 0.15
        }

        if !context.recentWorlds.contains(quest.world) { score += 0.15 }
        if !context.recentCanonicalLenses.contains(quest.canonicalLens) { score += 0.15 }

        if quest.defaultSurface == "General default" {
            score += 0.10
        } else if quest.defaultSurface == "Contextual default" {
            score += 0.08
        }

        return score
    }
}
