import SwiftUI

struct LabView: View {
    let currentQuest: QuestDefinition?
    let catalogVersion: String

    var body: some View {
        NavigationStack {
            Form {
                Section("Catalog") {
                    LabeledContent("Version", value: catalogVersion)
                    if let currentQuest {
                        LabeledContent("Seed", value: "#\(currentQuest.id)")
                        LabeledContent("World", value: currentQuest.world)
                        LabeledContent("Lens", value: currentQuest.canonicalLens)
                        LabeledContent("Rank", value: currentQuest.rank)
                        LabeledContent("Surface", value: currentQuest.defaultSurface)
                    }
                }
                Section("Prototype") {
                    Text("Event log export and score breakdown should be wired here before device testing.")
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Lab")
        }
    }
}
