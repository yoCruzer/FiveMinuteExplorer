import SwiftUI

struct ExploreView: View {
    let quests: [QuestDefinition]
    let onSelect: (QuestDefinition) -> Void

    private let moods = ["Easy", "Calm", "Think", "Move", "Listen", "Do nothing", "Weird", "Creative"]

    var body: some View {
        NavigationStack {
            List {
                Section("What feels right?") {
                    ForEach(moods, id: \.self) { mood in
                        NavigationLink(mood) {
                            QuestListView(
                                title: mood,
                                quests: quests.filter { quest in
                                    quest.moods.contains(mood) ||
                                    (mood == "Move" && quest.world == "Move a Little") ||
                                    (mood == "Listen" && quest.world == "Listen & Sense") ||
                                    (mood == "Do nothing" && quest.world == "Pause") ||
                                    (mood == "Creative" && quest.world == "Imagine & Create")
                                },
                                onSelect: onSelect
                            )
                        }
                    }
                }

                Section("Worlds") {
                    ForEach(Array(Set(quests.map(\.world))).sorted(), id: \.self) { world in
                        NavigationLink(world) {
                            QuestListView(
                                title: world,
                                quests: quests.filter { $0.world == world },
                                onSelect: onSelect
                            )
                        }
                    }
                }
            }
            .navigationTitle("Explore")
        }
    }
}

private struct QuestListView: View {
    let title: String
    let quests: [QuestDefinition]
    let onSelect: (QuestDefinition) -> Void

    var body: some View {
        List(quests.prefix(24)) { quest in
            Button {
                onSelect(quest)
            } label: {
                VStack(alignment: .leading, spacing: 4) {
                    Text(quest.title)
                    Text(quest.text)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
            }
        }
        .navigationTitle(title)
    }
}
