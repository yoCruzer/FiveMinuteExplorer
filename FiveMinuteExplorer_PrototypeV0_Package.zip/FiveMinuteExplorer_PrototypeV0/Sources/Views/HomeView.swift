import SwiftUI

struct HomeView: View {
    let quest: QuestDefinition?
    let onSkip: () -> Void
    let onExplore: () -> Void

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Spacer()

                if let quest {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(quest.title)
                            .font(.title2.bold())
                        Text(quest.text)
                            .font(.title3)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(24)
                } else {
                    ProgressView()
                }

                Spacer()

                HStack {
                    Button("Not for me", action: onSkip)
                    Spacer()
                    Button("Explore", action: onExplore)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
            .navigationTitle("Five-Minute Explorer")
        }
    }
}
