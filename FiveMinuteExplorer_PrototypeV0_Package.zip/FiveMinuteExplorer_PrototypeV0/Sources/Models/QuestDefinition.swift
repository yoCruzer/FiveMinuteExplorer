import Foundation

struct QuestDefinition: Codable, Identifiable, Hashable {
    let id: Int
    let originalSeed: String
    let title: String
    let text: String
    let world: String
    let rawLens: [String]
    let canonicalLens: String
    let actions: [String]
    let moods: [String]
    let time: String
    let energy: String
    let cognitiveLoad: String
    let movement: String
    let environment: [String]
    let context: [String]
    let depth: String
    let rank: String
    let defaultSurface: String
    let safety: [String]
    let whyKeep: String
    let catalogStatus: String

    var isFindHeavy: Bool { actions.contains("Find") }
}

struct QuestCatalogEnvelope: Codable {
    let catalogVersion: String
    let questCount: Int
    let quests: [QuestDefinition]
}
