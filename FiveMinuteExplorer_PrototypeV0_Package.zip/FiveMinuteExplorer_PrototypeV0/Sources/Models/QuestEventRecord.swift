import Foundation
import SwiftData

@Model
final class QuestEventRecord {
    @Attribute(.unique) var id: UUID
    var timestamp: Date
    var type: String
    var seedID: Int?
    var world: String?
    var canonicalLens: String?
    var reason: String?
    var source: String?

    init(
        id: UUID = UUID(),
        timestamp: Date = Date(),
        type: String,
        seedID: Int? = nil,
        world: String? = nil,
        canonicalLens: String? = nil,
        reason: String? = nil,
        source: String? = nil
    ) {
        self.id = id
        self.timestamp = timestamp
        self.type = type
        self.seedID = seedID
        self.world = world
        self.canonicalLens = canonicalLens
        self.reason = reason
        self.source = source
    }
}
