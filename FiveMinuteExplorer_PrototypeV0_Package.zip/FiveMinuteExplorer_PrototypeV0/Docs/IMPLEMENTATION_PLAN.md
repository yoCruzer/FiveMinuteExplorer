# Implementation Plan

## Stage 0 — Project bootstrap
Create a new native iOS SwiftUI project named `FiveMinuteExplorer` with a persistent `.xcodeproj`.
Suggested deployment target: iOS 17+.
Add `quests_v1.json` and `recommendation_v1.json` to the app bundle.

## Stage 1 — Catalog + models
Implement:
- `QuestDefinition`
- `QuestCatalogRepository`
- JSON bundle loader
- canonical helpers for mood/context arrays
Validation: app loads all 580 unique Seed IDs.

## Stage 2 — Local interaction data
Use SwiftData for append-only `QuestEventRecord`.
Keep content definitions outside SwiftData.
Add export to JSON from Lab.

## Stage 3 — Recommendation engine
Implement pure deterministic service:
- hard filter
- editorial/state scoring
- recent-history cooldowns
- World / Lens diversity
- Find-fatigue guardrail
- optional 20% controlled serendipity

Seed randomness can be injected so tests are reproducible.

## Stage 4 — UI
Build only:
- Home
- Quest focus card
- Explore shelves
- Lab

No onboarding flow beyond a tiny first-run explanation if needed.

## Stage 5 — Testability
Unit tests:
- catalog loads 580 unique IDs
- Experimental never enters general default
- context-only Quests are filtered when context does not match
- same Seed cooldown works
- Lens cooldown works
- no >2 same World default serves in a synthetic sequence
- no >2 Find-heavy default serves in a synthetic sequence
- deterministic selection under fixed random seed

## Stage 6 — Device usability
Use on real iPhone before adding capabilities.
Only after normal daily use exposes a concrete problem should MapKit, WeatherKit, AI, widgets, or notifications be considered.
