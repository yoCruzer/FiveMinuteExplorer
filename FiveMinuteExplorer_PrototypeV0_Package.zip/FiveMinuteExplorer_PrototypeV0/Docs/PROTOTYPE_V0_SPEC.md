# Five-Minute Explorer — Prototype V0

## Goal
Build a real, daily-usable iPhone prototype quickly, without turning a disposable demo into technical debt.

The prototype is not a full product. It must be good enough to use every day and to generate trustworthy behavioral feedback.

## Product loop
1. Open app.
2. Get one Quest.
3. Read it.
4. Look up / move / listen / pause.
5. Leave the phone.

Primary success is not screen time or completion. A Quest can succeed even if the user never returns to press Done.

## V0 screens
### 1. Home / Give Me One
- One prominent Quest card.
- Optional state chips: Easy, Calm, Think, Move, Listen, Do nothing.
- Actions: Not for me, Explore.
- Do not create an infinite reroll feed.
- After 1–2 skips, prompt for a state change or open Explore.

### 2. Explore
Finite shelves, not an endless feed.
- What feels right?: Easy / Calm / Think / Move / Listen / Do nothing / Weird / Create
- Worlds: the 10 Quest Worlds
- Context shelves only when useful: Waiting / Home / Work-School / Cafe-Restaurant / Transit / Travel / Night / Familiar Place / Nature Nearby

Selecting a Quest should leave Explore and show one focused Quest card. Do not show related content afterward.

### 3. Lab
Internal diagnostics only.
- Current Seed ID
- World / Canonical Lens / Rank / Default Surface
- Score breakdown
- Recent serves / skips
- Export event log JSON
- Catalog version

## Technical boundary
### Do now
- Native SwiftUI app.
- Stable Xcode project created once; do not generate the Xcode project dynamically.
- Bundle `quests_v1.json` as immutable catalog content.
- Local SwiftData for interaction events / lightweight preferences.
- Pure recommendation service behind a protocol.
- Local-only operation.
- Manual state/context inputs.
- Hidden/secondary Lab screen.

### Do not do in V0
- No login/account.
- No backend.
- No iCloud sync.
- No MapKit/POI search.
- No GPS permission.
- No WeatherKit.
- No LLM/AI generation.
- No push notifications.
- No Screen Time / Family Controls entitlement.
- No social feed.
- No XP, levels, streaks, badges.
- No mandatory completion.
- No photo proof.

## Data architecture
Keep three layers separate:
1. QuestDefinition — immutable bundled content.
2. UserState / Preferences — local lightweight state.
3. QuestEvent — append-only local behavior events.

Never hard-code the 580 Quests into Swift source.

## Recommended minimum event schema
- app_opened
- quest_served
- quest_skipped
- quest_selected_from_library
- state_changed
- more_like_this
- less_like_this
- event_log_exported

A missing completion event must never count as failure.

## Scope trade-off
Production-grade boundaries, prototype-grade scope.
Prefer fewer screens and a clean data/service boundary over feature completeness.
